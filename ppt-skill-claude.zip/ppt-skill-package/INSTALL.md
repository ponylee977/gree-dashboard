# PPT Skill 安装指南

## 快速安装

1. 将 `.claude/` 文件夹复制到你的项目根目录
2. 将 `skills/` 文件夹复制到你的项目根目录
3. 复制 `.env.example` 为 `.env` 并填入API密钥
4. 安装依赖: `pip install -r skills/ppt-generator/python/requirements.txt`

## 使用方法

在Claude Code中输入:
```
/ppt 你的PPT主题
```

例如:
```
/ppt 2025年Q1业绩分析
/ppt 投资路演
/ppt 产品培训手册
```

## 文件结构

```
your-project/
├── .claude/
│   └── commands/
│       └── ppt.md          # Skill命令文件
├── skills/
│   └── ppt-generator/
│       ├── python/
│       │   ├── intelligent_ppt_strategist.py
│       │   └── requirements.txt
│       ├── generate.sh
│       └── README.md
└── .env                     # API密钥配置
```
